<?php
// Fungsi untuk menambahkan meja baru
function tambahMeja($nomorMeja)
{
    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kasir2";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Sanitasi input untuk mencegah SQL injection
    $nomorMeja = $conn->real_escape_string($nomorMeja);

    // Query untuk menambahkan data meja baru
    $sql = "INSERT INTO `meja` (`nomorMeja`) VALUES ('$nomorMeja')";

    if ($conn->query($sql) === TRUE) {
        // Redirect ke halaman meja.php setelah penambahan berhasil
        header("Location: meja.php");
        exit();
    } else {
        // Redirect ke halaman meja.php dengan pesan error jika penambahan gagal
        header("Location: meja.php?error=2");
        exit();
    }

    // Tutup koneksi database
    $conn->close();
}

// Pastikan form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil nilai input dari form
    $nomorMeja = $_POST["nomorMeja"];

    // Panggil fungsi untuk menambahkan meja
    tambahMeja($nomorMeja);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Meja</title>
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="text-center card-header bg-primary text-white">
                        TAMBAH MEJA
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <div class="form-group">
                                <label for="nomorMeja">Nomor Meja</label>
                                <input type="text" class="form-control" id="nomorMeja" name="nomorMeja" required>
                            </div>
                            <button type="submit" class="btn btn-success btn-block">SIMPAN</button>
                        </form>
                        <a href="meja.php" class="btn btn-danger btn-block mt-3">BATAL</a>

                    </div>
                </div>
            </div>
        </div>

        
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
