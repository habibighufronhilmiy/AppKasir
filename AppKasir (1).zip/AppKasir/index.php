<?php
session_start();

// Gantilah dengan koneksi database Anda
$conn = mysqli_connect("localhost", "root", "", "kasir2");

$message = '';

if (!empty($_POST['username']) && !empty($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Pastikan tabel yang digunakan sesuai dengan nama tabel sebenarnya
    $sql = "SELECT * FROM user WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['iduser'] = $row['iduser']; // Simpan idUser ke dalam sesi jika diperlukan
        $_SESSION['username'] = $username;
        $_SESSION['level'] = $row['level'];

        // Sesuaikan dengan nama file dashboard yang sebenarnya
        header('Location: dashboard.php');
        exit();
    } else {
        $message = '<label>Wrong Username or Password</label>';
    }
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Additional styles for customization -->
    <style>
        body {
            background-color: #f8f9fc;
            /* Light Gray background color */
        }

        .container {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .card {
            border: 0;
            border-radius: 1.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.1);
        }

        .card-body {
            padding: 2rem;
        }

        .card-title {
            font-size: 1.5rem;
            font-weight: bold;
            color: #333;
            text-align: center;
            margin-bottom: 1.5rem;
        }

        .form-control-user {
            border-radius: 1.5rem;
        }

        .btn-user {
            border-radius: 1.5rem;
            background-color: #4e73df;
            /* Blue button color */
            border-color: #4e73df;
        }

        .btn-user:hover {
            background-color: #2e59d9;
            /* Darker blue button color on hover */
            border-color: #2653d4;
        }

        hr {
            margin: 1.5rem 0;
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .text-center {
            text-align: center;
        }

        .text-gray {
            color: #6c757d;
        }

        .small {
            font-size: 0.875rem;
        }

        .mb-4 {
            margin-bottom: 1.5rem;
        }

        .mt-4 {
            margin-top: 1.5rem;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="card o-hidden border-0 shadow-lg">
            <div class="card-body">
                <div class="p-4">
                    <div class="text-center">
                        <h1 class="card-title mb-4">Halaman Login</h1>
                    </div>
                    <form class="user" method="post" action="">
                        <div class="form-group">
                            <input type="text" class="form-control form-control-user" placeholder="Enter Username" name="username" required>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control form-control-user" placeholder="Enter Password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary btn-user btn-block">Login</button>
                    </form>
                    <hr>
                    <div class="text-center">
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>
