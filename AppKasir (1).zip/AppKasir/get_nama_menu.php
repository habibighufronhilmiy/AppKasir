<?php
// Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil idPesanan dari permintaan AJAX
$idPesanan = $_POST['idPesanan'];

// Query untuk mendapatkan nama menu dari pesanan
$sql = "SELECT namaMenu FROM pesan WHERE idPesanan = '$idPesanan'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $namaMenu = $row['namaMenu'];
    echo $namaMenu; // Mengembalikan nama menu ke JavaScript
} else {
    echo "Nama Menu Tidak Ditemukan"; // Jika tidak ada nama menu yang ditemukan
}

// Tutup koneksi database
$conn->close();
?>
