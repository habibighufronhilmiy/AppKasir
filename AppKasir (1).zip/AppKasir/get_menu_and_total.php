<?php
// Lakukan koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil idPesanan dari permintaan POST
$idPesanan = $_POST['idPesanan'];

// Kueri SQL untuk mendapatkan data nama menu dan total berdasarkan idPesanan
$sql = "SELECT namaMenu, SUM(harga * jumlah) AS total FROM pesan WHERE idPesanan = '$idPesanan'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Ambil data dari hasil kueri
    $row = $result->fetch_assoc();
    $namaMenu = $row['namaMenu'];
    $total = $row['total'];

    // Buat array asosiatif untuk dikirimkan kembali dalam format JSON
    $response = array('namaMenu' => $namaMenu, 'total' => $total);

    // Konversi array ke format JSON dan kirimkan kembali
    echo json_encode($response);
} else {
    // Jika tidak ada hasil, kirimkan respon kosong
    echo json_encode(null);
}

// Tutup koneksi database
$conn->close();
?>
