<?php
// Pastikan ID pesanan dikirimkan melalui parameter GET
if (isset($_GET['id'])) {
    $idPesanan = $_GET['id'];
} else {
    echo "ID pesanan tidak valid.";
    exit();
}

// Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

$conn = new mysqli($servername, $username, $password, $dbname);

// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk menghapus data pesanan berdasarkan ID
$sql = "DELETE FROM pesan WHERE idPesanan = $idPesanan";

if ($conn->query($sql) === TRUE) {
    // Redirect ke halaman waiter.php setelah penghapusan
    header("Location: waiter.php");
    exit();
} else {
    echo "Error deleting record: " . $conn->error;
}

// Tutup koneksi database
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Konfirmasi Hapus</title>
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-danger text-white">Konfirmasi Hapus</div>
                    <div class="card-body">
                        <p>Apakah Anda yakin ingin menghapus pesanan ini?</p>
                        <a href="waiter.php" class="btn btn-secondary">Batal</a>
                        <a href="#" onclick="deleteOrder()" class="btn btn-danger">Hapus</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script>
    function deleteOrder() {
        // Redirect ke halaman deleteOrderProcess.php untuk menghapus pesanan
        window.location.href = "waiter.php?id=<?= $idPesanan ?>";
    }
    </script>

</body>

</html>
