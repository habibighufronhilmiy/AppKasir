<?php
// Fungsi untuk menambahkan transaksi baru
function tambahTransaksi($idPesanan, $total, $bayar, $kembali)
{
    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kasir2";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Sanitasi input untuk mencegah SQL injection
    $idPesanan = $conn->real_escape_string($idPesanan);
    $total = $conn->real_escape_string($total);
    $bayar = $conn->real_escape_string($bayar);
    $kembali = $conn->real_escape_string($kembali);

    // Query untuk menambahkan data transaksi baru
    $sql = "INSERT INTO `transaksi` (`idPesanan`, `total`, `bayar`, `kembali`) VALUES ('$idPesanan', '$total', '$bayar', '$kembali')";

    if ($conn->query($sql) === TRUE) {
        // Redirect ke halaman kasir.php setelah penambahan berhasil
        header("Location: kasir.php");
        exit();
    } else {
        // Redirect ke halaman kasir.php dengan pesan error jika penambahan gagal
        header("Location: kasir.php?error=2");
        exit();
    }

    // Tutup koneksi database
    $conn->close();
}

// Pastikan form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil nilai input dari form
    $idPesanan = $_POST["idPesanan"];
    $total = $_POST["total"];
    $bayar = $_POST["bayar"];
    $kembali = $_POST["kembali"]; // Menambahkan ambil nilai kembalian

    // Panggil fungsi untuk menambahkan transaksi
    tambahTransaksi($idPesanan, $total, $bayar, $kembali);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Transaksi</title>
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="text-center card-header bg-primary text-white">
                        TAMBAH TRANSAKSI
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <div class="form-group">
                                <label for="idPesanan">ID Pesanan</label>
                                <select class="form-control" id="idPesanan" name="idPesanan" required>
                                    <?php
                                    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "";
                                    $dbname = "kasir2";

                                    $conn = new mysqli($servername, $username, $password, $dbname);

                                    // Periksa koneksi
                                    if ($conn->connect_error) {
                                        die("Koneksi gagal: " . $conn->connect_error);
                                    }

                                    // Query untuk mendapatkan daftar ID Pesanan
                                    $sql = "SELECT idPesanan FROM pesan";
                                    $result = $conn->query($sql);

                                    // Tampilkan pilihan ID Pesanan
                                    while ($row = $result->fetch_assoc()) {
                                        echo "<option value='" . $row['idPesanan']. "'>" . $row['idPesanan'] . "</option>";
                                    }

                                    // Tutup koneksi database
                                    $conn->close();
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="namaMenu">Nama Menu</label>
                                <input type="text" class="form-control" id="namaMenu" name="namaMenu" readonly>
                            </div>
                            <div class="form-group">
                                <label for="total">Total</label>
                                <input type="text" class="form-control" id="total" name="total" readonly>
                            </div>
                            <div class="form-group">
                                <label for="bayar">Bayar</label>
                                <input type="text" class="form-control" id="bayar" name="bayar" required>
                            </div>
                            <div class="form-group">
                                <label for="kembali">Kembalian</label>
                                <input type="number" class="form-control" id="kembali" name="kembali" readonly>
                            </div>

                            <button type="submit" class="btn btn-success btn-block">SIMPAN</button>
                        </form>
                        <a href="kasir.php" class="btn btn-danger btn-block mt-3">BATAL</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function () {
            // Event listener untuk perubahan pada select idPesanan
            $('#idPesanan').change(function () {
                var idPesanan = $(this).val();
                // Panggil AJAX untuk mendapatkan nama menu dan total berdasarkan idPesanan
                $.ajax({
                    type: 'POST',
                    url: 'get_menu_and_total.php',
                    data: { idPesanan: idPesanan },
                    success: function (response) {
                        var data = JSON.parse(response);
                        $('#namaMenu').val(data.namaMenu);
                        $('#total').val(data.total);
                    }
                });
            });

            // Event listener untuk perubahan pada input bayar
            $('#bayar').on('input', function () {
                var total = parseFloat($('#total').val());
                var bayar = parseFloat($(this).val());
                // Hitung kembalian
                var kembalian = bayar - total;
                // Tampilkan kembalian
                $('#kembali').val(kembalian.toFixed(2));
            });
        });
    </script>

</body>

</html>

