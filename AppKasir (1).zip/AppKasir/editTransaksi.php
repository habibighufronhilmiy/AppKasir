<?php
// Fungsi untuk mengupdate transaksi
function updateTransaksi($idTransaksi, $idPesanan, $total, $bayar, $kembali)
{
    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kasir2";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Sanitasi input untuk mencegah SQL injection
    $idTransaksi = $conn->real_escape_string($idTransaksi);
    $idPesanan = $conn->real_escape_string($idPesanan);
    $total = $conn->real_escape_string($total);
    $bayar = $conn->real_escape_string($bayar);
    $kembali = $conn->real_escape_string($kembali);

    // Query untuk mengupdate data transaksi
    $sql = "UPDATE transaksi SET idPesanan='$idPesanan', total='$total', bayar='$bayar', kembali='$kembali' WHERE idTransaksi='$idTransaksi'";

    if ($conn->query($sql) === TRUE) {
        // Redirect ke halaman transaksi.php setelah update berhasil
        header("Location: kasir.php");
        exit();
    } else {
        // Redirect ke halaman transaksi.php dengan pesan error jika update gagal
        header("Location: kasir.php?error=3");
        exit();
    }

    // Tutup koneksi database
    $conn->close();
}

// Fungsi untuk mendapatkan data transaksi dari database berdasarkan ID
function getTransaksiById($idTransaksi)
{
    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kasir2";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Query untuk mendapatkan data transaksi berdasarkan ID
    $sql = "SELECT * FROM transaksi WHERE idTransaksi='$idTransaksi'";
    $result = $conn->query($sql);

    // Tutup koneksi database
    $conn->close();

    return $result->fetch_assoc();
}

// Pastikan form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil nilai input dari form
    $idTransaksi = $_POST["idTransaksi"];
    $idPesanan = $_POST["idPesanan"];
    $total = $_POST["total"];
    $bayar = $_POST["bayar"];
    $kembali = $bayar - $total; // Hitung kembalian

    // Panggil fungsi untuk mengupdate transaksi
    updateTransaksi($idTransaksi, $idPesanan, $total, $bayar, $kembali);
} elseif (isset($_GET["id"])) {
    // Ambil ID dari parameter GET
    $idTransaksi = $_GET["id"];

    // Panggil fungsi untuk mendapatkan data transaksi berdasarkan ID
    $transaksiData = getTransaksiById($idTransaksi);

    // Periksa apakah data transaksi ditemukan
    if (!$transaksiData) {
        // Redirect ke halaman transaksi.php jika data tidak ditemukan
        header("Location: kasir.php");
        exit();
    }
} else {
    // Redirect ke halaman transaksi.php jika tidak ada ID
    header("Location: kasir.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Transaksi</title>
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="text-center card-header bg-primary text-white">
                        EDIT TRANSAKSI
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <input type="hidden" name="idTransaksi" value="<?= $transaksiData['idTransaksi'] ?>">
                            <div class="form-group">
                                <label for="idPesanan">ID Pesanan:</label>
                                <input type="text" class="form-control" id="idPesanan" name="idPesanan" value="<?= $transaksiData['idPesanan'] ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="total">Total:</label>
                                <input type="text" class="form-control" id="total" name="total" value="<?= $transaksiData['total'] ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="bayar">Bayar:</label>
                                <input type="text" class="form-control" id="bayar" name="bayar" value="<?= $transaksiData['bayar'] ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="kembali">Kembalian:</label>
                                <input type="text" class="form-control" id="kembali" name="kembali" value="<?= $transaksiData['kembali'] ?>" readonly>
                            </div>
                            <button type="submit" class="btn btn-success btn-block">MEMPERBARUI</button>
                        </form>
                        <a href="kasir.php" class="btn btn-danger btn-block mt-3">BATAL</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function () {
            // Event listener untuk perubahan pada input bayar
            $('#bayar').on('input', function () {
                var total = parseFloat($('#total').val());
                var bayar = parseFloat($(this).val());
                // Hitung kembalian
                var kembalian = bayar - total;
                // Tampilkan kembalian
                $('#kembali').val(kembalian.toFixed(2));
            });
        });
    </script>

</body>

</html>

