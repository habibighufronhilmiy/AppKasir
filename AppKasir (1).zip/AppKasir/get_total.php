<?php
// Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

$conn = new mysqli($servername, $username, $password, $dbname);
    
// Periksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil idPesanan dari permintaan AJAX
$idPesanan = $_POST['idPesanan'];

// Query untuk mendapatkan total harga dari pesanan
$sql = "SELECT SUM(harga) AS total FROM pesan WHERE idPesanan = '$idPesanan'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total = $row['total'];
    echo $total; // Mengembalikan total harga ke JavaScript
} else {
    echo "0"; // Jika tidak ada total yang ditemukan
}

// Tutup koneksi database
$conn->close();
?>
