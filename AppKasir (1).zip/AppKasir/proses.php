<?php
// Konfigurasi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data menu
$sql = "SELECT idPesanan, idPelanggan, nomorMeja, namaMenu, idMenu, harga, jumlah, idUser FROM pesan";
$result = $conn->query($sql);

// Memeriksa apakah ada hasil
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["idPesanan"] . "</td>
                <td>" . $row["idPelanggan"] . "</td>
                <td>" . $row["nomorMeja"] . "</td>
                <td>" . $row["namaMenu"] . "</td>
                <td>" . $row["idMenu"] . "</td>
                <td>" . $row["harga"] . "</td>
                <td>" . $row["jumlah"] . "</td>
                <td>" . $row["idUser"] . "</td>
                <td>  
                <a href='editOrder.php?id=" . $row["idPesanan"] . "' class='btn btn-warning btn-sm'>Edit</a>
                <a href='deleteOrder.php?id=" . $row["idPesanan"] . "' class='btn btn-danger btn-sm'>Hapus</a>
            </td>
          </tr>";
    }
} else {
    echo "0 hasil";
}

// Menutup koneksi database
$conn->close();
?>
