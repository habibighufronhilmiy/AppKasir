<?php
// Konfigurasi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data menu
$sql = "SELECT idTransaksi, idPesanan, total, bayar, kembali FROM transaksi";
$result = $conn->query($sql);

// Menampilkan data transaksi
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["idTransaksi"] . "</td>
                <td>" . $row["idPesanan"] . "</td>
                <td>" . $row["total"] . "</td>
                <td>" . $row["bayar"] . "</td>
                <td>" . $row["kembali"] . "</td>
                <td>
                <a href='editTransaksi.php?id=" . $row["idTransaksi"] . "' class='btn btn-warning btn-sm'>Edit</a>
                <a href='deletetransaksi.php?id=" . $row["idTransaksi"] . "' class='btn btn-danger btn-sm'>Hapus</a>
                </td>
            </tr>";
    }
} else {
    echo "0 hasil";
}

// Menutup koneksi database
$conn->close();
?>