<?php
// Fungsi untuk mengupdate meja
function updateMeja($mejaId, $nomorMeja)
{
    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kasir2";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Sanitasi input untuk mencegah SQL injection
    $mejaId = $conn->real_escape_string($mejaId);
    $nomorMeja = $conn->real_escape_string($nomorMeja);

    // Query untuk mengupdate data meja
    $sql = "UPDATE `meja` SET `nomorMeja`='$nomorMeja' WHERE `idMeja`='$mejaId'";

    if ($conn->query($sql) === TRUE) {
        // Redirect ke halaman meja.phpsetelah update berhasil
        header("Location: meja.php");
        exit();
    } else {
        // Redirect ke halaman meja.phpdengan pesan error jika update gagal
        header("Location: meja.php?error=3");
        exit();
    }

    // Tutup koneksi database
    $conn->close();
}

// Fungsi untuk mendapatkan data meja dari database berdasarkan ID
function getMejaById($mejaId)
{
    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kasir2";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Query untuk mendapatkan data meja berdasarkan ID
    $sql = "SELECT * FROM `meja` WHERE `idMeja`='$mejaId'";
    $result = $conn->query($sql);

    // Tutup koneksi database
    $conn->close();

    return $result->fetch_assoc();
}

// Pastikan form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil nilai input dari form
    $mejaId = $_POST["mejaId"];
    $nomorMeja = $_POST["nomorMeja"];

    // Panggil fungsi untuk mengupdate meja
    updateMeja($mejaId, $nomorMeja);
} elseif (isset($_GET["id"])) {
    // Ambil ID dari parameter GET
    $mejaId = $_GET["id"];

    // Panggil fungsi untuk mendapatkan data meja berdasarkan ID
    $mejaData = getMejaById($mejaId);

    // Periksa apakah data meja ditemukan
    if (!$mejaData) {
        // Redirect ke halaman meja.phpjika data tidak ditemukan
        header("Location: meja.php");
        exit();
    }
} else {
    // Redirect ke halaman meja.phpjika tidak ada ID
    header("Location: meja.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Meja</title>
    <!-- Bootstrap CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>

    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card">
                    <div class="text-center card-header bg-primary text-white">
                        EDIT MEJA
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <input type="hidden" name="mejaId" value="<?= $mejaData['idMeja'] ?>">
                            <div class="form-group">
                                <label for="nomorMeja">Nomor Meja:</label>
                                <input type="text" class="form-control" id="nomorMeja" name="nomorMeja" value="<?= $mejaData['nomorMeja'] ?>" required>
                            </div>
                            <button type="submit" class="btn btn-success btn-block">MEMPERBARUI</button>
                        </form>
                        <a href="meja.php" class="btn btn-danger btn-block mt-3">BATAL</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
