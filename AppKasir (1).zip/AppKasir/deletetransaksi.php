<?php
// Fungsi untuk menghapus transaksi berdasarkan ID
function deleteTransaksi($transaksiId)
{
    // Lakukan koneksi ke database (gunakan koneksi yang sesuai dengan kebutuhan Anda)
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "kasir2";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Periksa koneksi
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Sanitasi input untuk mencegah SQL injection
    $transaksiId = $conn->real_escape_string($transaksiId);

    // Query untuk menghapus data transaksi
    $sql = "DELETE FROM `transaksi` WHERE `idTransaksi`='$transaksiId'";

    if ($conn->query($sql) === TRUE) {
        // Redirect ke halaman transaksi.php setelah hapus berhasil
        header("Location: kasir.php");
        exit();
    } else {
        // Redirect ke halaman transaksi.php dengan pesan error jika hapus gagal
        header("Location: kasir.php?error=4");
        exit();
    }

    // Tutup koneksi database
    $conn->close();
}

// Pastikan parameter ID transaksi ada pada URL
if (isset($_GET["id"])) {
    // Ambil ID transaksi dari parameter GET
    $transaksiId = $_GET["id"];

    // Panggil fungsi untuk menghapus transaksi berdasarkan ID
    deleteTransaksi($transaksiId);
} else {
    // Redirect ke halaman transaksi.php jika tidak ada ID transaksi
    header("Location: kasir.php");
    exit();
}
