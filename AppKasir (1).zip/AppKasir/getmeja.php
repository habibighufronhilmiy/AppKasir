<?php
// Konfigurasi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data menu
$sql = "SELECT idMeja, nomorMeja FROM meja";
$result = $conn->query($sql);

// Memeriksa apakah ada hasil
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["idMeja"] . "</td>
                <td>" . $row["nomorMeja"] . "</td>;
                <td>";

        // Cek apakah halaman saat ini adalah admin.php
        if (basename($_SERVER['PHP_SELF']) == 'meja.php') {
            // Tampilkan tombol Edit dan Hapus jika halaman adalah admin.php
            echo "<a href='editmeja.php?id=" . $row["idMeja"] . "' class='btn btn-warning btn-sm'>Edit</a>
                  <a href='deletemeja.php?id=" . $row["idMeja"] . "' class='btn btn-danger btn-sm'>Hapus</a>";
        }

        echo "</td>
              </tr>";
    }
} else {
    echo "0 hasil";
}

// Menutup koneksi database
$conn->close();
