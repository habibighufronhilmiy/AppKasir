<?php
// Konfigurasi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "kasir2";

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Mengambil data menu
$sql = "SELECT idTransaksi, idPesanan, total, bayar FROM transaksi";
$result = $conn->query($sql);

// Menampilkan data transaksi
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["idTransaksi"] . "</td>
                <td>" . $row["idPesanan"] . "</td>
                <td>" . $row["total"] . "</td>
                <td>" . $row["bayar"] . "</td>
                <td>
                
                </td>
            </tr>";
    }
} else {
    echo "0 hasil";
}

// Menutup koneksi database
$conn->close();
?>